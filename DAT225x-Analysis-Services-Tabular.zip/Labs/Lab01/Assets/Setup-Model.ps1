Invoke-ASCmd �InputFile "F:\Labs\Setup\Scripts\Lab01-Setup-Reseller_Sales.json" -Server "localhost"
Invoke-ASCmd �InputFile "F:\Labs\Setup\Scripts\Lab01-Setup-Reseller_Sales-Process.json" -Server "localhost" 
pause