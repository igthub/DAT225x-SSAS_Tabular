PRINT N'Restore the AdventureWorksDW2016 database';
GO
IF EXISTS(SELECT * FROM [sys].[databases] WHERE [name]=N'AdventureWorksDW2016')
BEGIN
	PRINT N'** Database already exists - database not restored **';
END
ELSE
BEGIN
	RESTORE DATABASE [AdventureWorksDW2016] FROM  DISK = N'F:\Labs\Setup\Backups\AdventureWorksDW2016-DAT225x.bak'
	WITH
		FILE = 1
		,MOVE N'AdventureWorksDW2014_Data' TO N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\AdventureWorksDW2016_Data.mdf'
		,MOVE N'AdventureWorksDW2014_Log' TO N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\AdventureWorksDW2016_Log.ldf'
		,NOUNLOAD
		,REPLACE
		,STATS = 100;
END;
GO

PRINT N'Create the NT SERVICE\MSSQLServerOLAPService login';
GO
IF EXISTS(SELECT * FROM [sys].[syslogins] WHERE [name] = N'NT SERVICE\MSSQLServerOLAPService')
BEGIN
	PRINT N'** Login already exists - login not created **';
END
ELSE
BEGIN
	CREATE LOGIN [NT SERVICE\MSSQLServerOLAPService] FROM WINDOWS
		WITH DEFAULT_DATABASE=[master];
END;
GO