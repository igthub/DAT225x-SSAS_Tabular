PRINT N'Create the NT SERVICE\MSSQLServerOLAPService user';
GO
IF EXISTS(SELECT * FROM [sys].[sysusers] WHERE [name] = N'NT SERVICE\MSSQLServerOLAPService')
BEGIN
	PRINT N'** User already exists - user not created **';
END
ELSE
BEGIN
	CREATE USER [NT SERVICE\MSSQLServerOLAPService] FOR LOGIN [NT SERVICE\MSSQLServerOLAPService]
		WITH DEFAULT_SCHEMA=[dbo];
END;
GO

PRINT N'Add the NT SERVICE\MSSQLServerOLAPService user to the db_datareader role';
GO
ALTER ROLE [db_datareader]
	ADD MEMBER [NT SERVICE\MSSQLServerOLAPService];
GO

PRINT N'Update one employee (286) record LoginID';
GO
SET NOCOUNT ON;
GO
UPDATE
	[dbo].[DimEmployee]
SET
	[LoginID] = SUSER_SNAME()
WHERE
	[EmployeeKey] = 286;
GO
SET NOCOUNT OFF;
GO

PRINT N'Update employee IDs';
GO
SET NOCOUNT ON;
GO
UPDATE
	[dbo].[DimEmployee]
SET
	[EmployeeNationalIDAlternateKey] = N'AW' + [EmployeeNationalIDAlternateKey]
WHERE
	LEFT([EmployeeNationalIDAlternateKey], 2) <> N'AW';
GO
SET NOCOUNT OFF;
GO